import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DataStruct} from '../../Entities/DataStruct';
import { UserService } from '../../app/user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
 
  // submitted = false;
  // 
  
  constructor(private user: UserService, private router: Router) { }

  ngOnInit() {
  }

//   //  onSubmit(f:NgForm) { this.submitted = true;
//   //   console.log("Product Id: "+this.productId);
//   //   console.log("Product Name: "+this.productName);
//   //   console.log("Product Description: "+this.productDes);
//   //   console.log("Product Price: "+this.productPrice);
   
//   // }

// postData() {
//     this.user.postData(this.productId, this.productName, this.productDes, this.productPrice).subscribe();
//   }
   

   /**
    * 
    postData(ename: string, eduration: number): Observable<any> {
    return this.http.post('http://localhost:4004/add', {
      courseName: ename,
      courseDuration: eduration
    });
  }
*/    

}
