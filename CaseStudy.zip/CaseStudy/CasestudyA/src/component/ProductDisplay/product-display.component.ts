import { Component, OnInit } from '@angular/core';
import { UserService } from '../../app/user.service';
import { Router } from '@angular/router';
import { DataStruct } from '../../Entities/dataStruct';
@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent implements OnInit {

  constructor(private user: UserService, private router: Router) { }
   public data: DataStruct[] = [];
   public productId:number;
   public productName:string;
   public productDes:string;
   public productPrice:number;
   public prodId:number;
   public prodName:string;
   public prodDes:string;
   public prodPrice:number;
   p:number=1;

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.user.getData().subscribe(data => this.data=data);

  }
  resetData(){
    this.productId=null;
    this.productName="";
    this.productDes="";
    this.productPrice=null;
  }
  addProduct(){
    //this.router.navigate(['/addProduct']);
    this.user.postData(this.productId, this.productName, this.productDes, this.productPrice).subscribe((data)=>this.data=data);
    this.getData();
    this.resetData();
  }
  editfun(id){
    for(var prod of this.data){
      if(prod.id==id){
        this.prodId = prod.id;
        this.prodName = prod.Name;
        this.prodDes = prod.Description;
        this.prodPrice = prod.Price;
        //console.log(this.prodId,this.prodName,this.prodDes,this.prodPrice);
        //console.log("EditFun OUt");
      }
    }
  }
  updateProduct(id:number,name:string,des:string,price:number){
    this.prodId = id;
    this.prodName = name;
    this.prodDes = des;
    this.prodPrice = price;
    this.user.updateData(this.prodId, this.prodName, this.prodDes, this.prodPrice).subscribe((data)=>this.data=data);
    //this.getData();
  }
  remove(id:number){
    this.user.removeData(id).subscribe((data: DataStruct[]) => this.data = data);
  }
}
