export interface DataStruct{
    id:number;
    Name:string;
    Description:string;
    Price:number;
}