//importing libraries
var http = require('http');
var express = require('express');
var data = require('./products.json')
var parser = require('body-parser');
var fs = require('fs');
var cors = require('cors');
var exp = express();
exp.use(cors())
//Declaring Vaiables
var appendData = data;
var _url = '/get';
var _url1 = '/add';
var _url2 = '/edit';
var _url3 = '/delete/:id';

exp.route(_url,'/*',cors()).get((req,res)=>{
    console.log("Get Url invoked");
    res.send(data);
});

exp.use(parser.json());
exp.route(_url1,cors()).post((req,res)=>{
    console.log("Add Url invoked")
    var Obj = req.body;
    console.log(Obj);
    appendData.push(Obj);
   // console.log(appendData);
    res.send(appendData);
    fs.writeFileSync('products.json',JSON.stringify(appendData));
    }
);

exp.route(_url2,cors()).put((req,res)=>{
    console.log("Update Url invoked")
   // res.writeHead(200, {'Content-Type': 'text/json'});
    for(var prod  of data) {
        if(prod.id==req.body.id){
            prod.id = req.body.id;
            prod.Name = req.body.Name;
            prod.Description = req.body.Description;
            prod.Price = req.body.Price;
        }
        fs.writeFileSync('products.json',JSON.stringify(data));
    }
    res.send(data);
});

exp.route(_url3,cors()).delete((req,res)=>{
    console.log("Delete Url invoked");
    for(var e in data){
        if(data[e].id==req.params.id){
            data.splice(e,1);
            console.log("Inside");
        }
        
        fs.writeFileSync('products.json',JSON.stringify(data));
    }
    res.send(data);
});

exp.listen(3001,()=>console.log("Running"));

